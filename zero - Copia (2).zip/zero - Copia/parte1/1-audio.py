import numpy as np
import soundcard as sc

seconds = 5
samplerate = 48000
numframes = 1024
blocksize = 4096
iterator = range(0, samplerate * seconds // numframes)

mic = sc.default_microphone()
spk = sc.default_speaker()

array = []
with mic.recorder(samplerate=samplerate, channels=2, blocksize=blocksize) as rec:
    for i in iterator:
        data = rec.record(numframes=numframes)
        array.append(data)

audio = np.concatenate(array)
print(audio)
print(audio.size)

with spk.player(samplerate=samplerate, channels=2, blocksize=blocksize) as player:
    player.play(audio / np.max(np.abs(audio)))
