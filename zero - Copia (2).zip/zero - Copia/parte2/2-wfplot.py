import numpy as np
import soundcard as sc
import matplotlib.pyplot as plt

seconds = 5
samplerate = 48000
numframes = 1024
blocksize = 4096
iterator = range(0, samplerate * seconds // numframes)

mic = sc.default_microphone()
spk = sc.default_speaker()

array = []
with mic.recorder(samplerate=samplerate, channels=2, blocksize=blocksize) as rec:
    for i in iterator:
        data = rec.record(numframes=numframes)
        array.append(data)

audio = np.concatenate(array)
print(audio)
print(audio.size)
print(len(audio))
print(audio.shape)

with spk.player(samplerate=samplerate, channels=2, blocksize=blocksize) as player:
    player.play(audio / np.max(np.abs(audio)))

x = range(len(audio))

plt.rcParams["figure.figsize"] = [12, 7.5]
plt.rcParams["figure.autolayout"] = True

plt.plot(x, audio, color="blue")
plt.title("Random graph")

plt.show()